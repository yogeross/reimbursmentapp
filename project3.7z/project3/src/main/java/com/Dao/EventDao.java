package com.Dao;

import java.sql.SQLException;
import java.util.List;

import com.beans.Event;

public interface EventDao {
	public List<Event> geteventList() throws SQLException;
	public Event getEvent (int event_id)throws SQLException;

}
