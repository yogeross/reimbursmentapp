package com.Dao;

import java.sql.SQLException;
import java.util.List;

import com.beans.Request;

public interface RequestDao {
	public List<Request> getrequestList() throws SQLException;

}
