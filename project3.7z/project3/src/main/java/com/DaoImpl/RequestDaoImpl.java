package com.DaoImpl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.Dao.EmployeeDao;
import com.Dao.RequestDao;
import com.beans.Request;
import com.util.ConnFactory;

public class RequestDaoImpl implements RequestDao {
	
	public static ConnFactory cf = ConnFactory.getInstance();
	
	public List<Request> getrequestList() throws SQLException {
		List<Request> requestList = new ArrayList<Request>(); 
		Connection conn= cf.getConnection();
		// TODO Auto-generated method stub
		Statement stmt= conn.createStatement();
		ResultSet rs= stmt.executeQuery("SELECT * FROM Request");
		Request s= null;
		while(rs.next()) {
			s= new Request(rs.getInt(1),rs.getInt(2));
			requestList.add(s);
			
		}
		return requestList;
	}

	
public Request getRequest (int employee_id) {
		
		Connection conn = cf.getConnection();
		String sql = "SELECT * FROM REQUEST WHERE employee_id = ?";
		PreparedStatement ps;
		try {
			ps = conn.prepareStatement(sql);
			ps.setInt(1, employee_id);
			ResultSet rs = ps.executeQuery();
			rs.next();
			return new Request( rs.getInt(2),rs.getInt(3));
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return null;
}
}