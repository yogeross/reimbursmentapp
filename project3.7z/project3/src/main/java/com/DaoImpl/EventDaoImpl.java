package com.DaoImpl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.Dao.EventDao;
import com.Dao.RequestDao;
import com.beans.Event;
import com.beans.Request;
import com.util.ConnFactory;

public class EventDaoImpl implements EventDao {

public static ConnFactory cf = ConnFactory.getInstance();
	
	public List<Event> geteventList() throws SQLException {
		List<Event> eventList = new ArrayList<Event>(); 
		Connection conn= cf.getConnection();
		// TODO Auto-generated method stub
		Statement stmt= conn.createStatement();
		ResultSet rs= stmt.executeQuery("SELECT * FROM Event");
		Event s= null;
		while(rs.next()) {
			s= new Event(rs.getInt(1),rs.getInt(2),rs.getInt(3),rs.getString(4),rs.getString(5),rs.getString(6),rs.getString(7),rs.getString(8),rs.getString(9),rs.getDouble(10));
			eventList.add(s);
			
		}
		return eventList;

}
 public Event getEvent (int event_id) {
		
		Connection conn = cf.getConnection();
		String sql = "SELECT * FROM EVENT WHERE event_id = ?";
		PreparedStatement ps;
		try {
			ps = conn.prepareStatement(sql);
			ps.setInt(1, event_id);
			ResultSet rs = ps.executeQuery();
			rs.next();
			return new Event( rs.getInt(2),rs.getInt(3) ,rs.getInt(4),rs.getString(5),rs.getString(6),rs.getString(7),rs.getString(8),rs.getString(9),rs.getString(10),);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return null;
}
}
	}
